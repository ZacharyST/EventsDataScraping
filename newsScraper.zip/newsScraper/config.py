import html2text
### This is your config file.
### Here you can change the searching keywords ,data and time. 

### This is a Python dictionary
Config ={}

### Enter The Starting Date In the Given Order
### If you want to change the start date then change the values.
### value must be enclosed in single quotes

Config['start_year']='2011'
Config['start_month']='01'
Config['start_day']='01'                                             

### Enter The Last Date In the Given Order
### If you want to change the last date then change the values.
### value must be enclosed in single quotes

Config['end_year']='2011'
Config['end_month']='01'
Config['end_day']='31'

### Enter The Keywords in the list for searching on the news websites
### Each keyword must be separated by , and enclosed in single quotes
### E.g. if you want to add India as one of the keywords to be searched
### then change the array from Config['keywordsList'] = ['egypt','Libya']
### to Config['keywordsList'] = ['egypt','Libya', 'India']
Config['dateformat']='%y%m%d'

Config['keywordsList'] = ['United Arab Emirates','united arab emirates', 'dubai','Dubai','Abu Dhabi','abu dhabi']

def html2texthandler(html):
    h = html2text.HTML2Text();
    h.ignore_images = True;
    h.ignore_links = True;
    
    return h.handle(html)
